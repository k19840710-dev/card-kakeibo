# sai — CardManager Pro（カード家計簿）

クレジットカードの利用額を毎月記録・管理できる React 製の家計簿アプリです。
Vite + React + Tailwind CSS + lucide-react で構築されています。データは端末のブラウザ内（`localStorage`）に保存され、外部サーバーへの通信は行いません。

> **注記**: 以前のバニラ JS 版（テーブル形式の明細・iOS 風ライトテーマ）から、この React 版へ全面移行しました。データ構造が異なるため、旧バージョンで記録した内容は自動的には引き継がれません。

## 主な機能

**ダッシュボード**
- 今月の合計利用額（前月比つき）
- 月別支出推移グラフ（全カード合計／カード別を切り替え可能）
- カードごとの利用状況（グラデーションカードデザイン、利用枠ゲージ、締め日・支払日）
- カテゴリ別支出内訳

**明細一覧**
- カード・カテゴリでの絞り込み
- 利用明細の記録・削除

**カード管理**
- カードの追加（ブランド・下4桁・デザインカラー・利用限度額・締め日・支払日）・削除

すべてのデータは `localStorage` に自動保存され、ページを再読み込みしても消えません。

## セットアップ

```bash
npm install
npm run dev       # 開発サーバーを起動（http://localhost:5173）
```

## ビルド

```bash
npm run build      # 通常のビルド（dist/ に出力、GitHub Pages などの静的ホスティング向け）
npm run preview    # ビルド結果をローカルで確認
```

`dist/` を GitHub Pages や Netlify、Vercel などの静的ホスティングにそのままデプロイできます。

## ディレクトリ構成

```
.
├── index.html               # Vite エントリーポイント
├── src/
│   ├── main.jsx              # Reactマウント処理
│   ├── App.jsx                # アプリ本体（画面構成・状態管理）
│   ├── index.css              # Tailwindエントリー
│   └── components/
│       └── TrendChart.jsx     # 月別支出推移グラフ（SVG自作コンポーネント）
├── vite.config.js            # 通常ビルド設定
├── vite.artifact.config.js   # 単一HTMLファイル用ビルド設定（build:artifact）
├── tailwind.config.js
└── postcss.config.js
```

## データについて

すべてのデータはブラウザの `localStorage` に保存されるため、別の端末・別のブラウザとは同期されません。ブラウザのデータを消去すると記録も失われるため、重要な場合は各自でバックアップ手段の追加をご検討ください。
