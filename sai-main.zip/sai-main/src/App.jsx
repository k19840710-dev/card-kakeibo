import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  CreditCard,
  Plus,
  Calendar,
  ChevronLeft,
  ChevronRight,
  PieChart,
  List,
  Trash2,
  Wallet,
  Tag,
  TrendingUp,
  X,
  Filter,
  ShoppingBag,
  Utensils,
  Car,
  Home,
  Tv,
  HelpCircle,
  Sparkles,
  Eye,
  EyeOff,
  User,
  Download,
  Upload,
} from 'lucide-react';
import TrendChart from './components/TrendChart.jsx';

// ---------- localStorage ----------

const STORAGE_KEYS = {
  cards: 'cardTracker.cards',
  transactions: 'cardTracker.transactions',
};

function loadList(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length ? parsed : fallback;
  } catch (e) {
    console.error('保存データの読み込みに失敗しました', e);
    return fallback;
  }
}

// カードのデザインスタイル定義
const CARD_THEMES = {
  purple: {
    bg: 'bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500',
    border: 'border-purple-400/30',
    text: 'text-white',
    badge: 'bg-purple-900/40 text-purple-200',
  },
  dark: {
    bg: 'bg-gradient-to-br from-gray-900 via-slate-800 to-black',
    border: 'border-gray-700',
    text: 'text-white',
    badge: 'bg-gray-800 text-gray-300',
  },
  emerald: {
    bg: 'bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700',
    border: 'border-teal-400/30',
    text: 'text-white',
    badge: 'bg-teal-900/40 text-teal-200',
  },
  blue: {
    bg: 'bg-gradient-to-br from-blue-600 via-cyan-600 to-indigo-700',
    border: 'border-blue-400/30',
    text: 'text-white',
    badge: 'bg-blue-900/40 text-blue-200',
  },
  sunset: {
    bg: 'bg-gradient-to-br from-amber-500 via-orange-600 to-red-600',
    border: 'border-orange-400/30',
    text: 'text-white',
    badge: 'bg-orange-900/40 text-orange-200',
  },
};

// カテゴリ定義
const CATEGORIES = [
  { id: 'food', name: '食費', icon: Utensils, color: 'bg-amber-500 text-amber-500' },
  { id: 'shopping', name: '買い物', icon: ShoppingBag, color: 'bg-blue-500 text-blue-500' },
  { id: 'transport', name: '交通費', icon: Car, color: 'bg-emerald-500 text-emerald-500' },
  { id: 'housing', name: '固定費・住居', icon: Home, color: 'bg-purple-500 text-purple-500' },
  { id: 'entertainment', name: '娯楽・趣味', icon: Tv, color: 'bg-pink-500 text-pink-500' },
  { id: 'other', name: 'その他', icon: HelpCircle, color: 'bg-gray-500 text-gray-500' },
];

// 店名・利用先の文字列に含まれるキーワードから、カテゴリを推測するための対応表。
// スクリーンショット読み取り（OCR）で使う。優先度は上から順。
const CATEGORY_KEYWORDS = [
  ['food', ['スーパー', 'マルエツ', 'イオン', '成城石井', 'コンビニ', 'セブン', 'ローソン', 'ファミリーマート', 'ファミマ', 'マクドナルド', 'モスバーガー', 'スターバックス', 'ドトール', 'カフェ', 'コーヒー', 'レストラン', '食堂', '弁当', '居酒屋', 'サイゼリヤ', '吉野家', 'すき家', '松屋', 'ラーメン', '寿司', '焼肉']],
  ['transport', ['Suica', 'PASMO', 'ETC', '新幹線', 'ＪＲ', 'JR', '電車', 'バス', 'タクシー', 'Cycling', 'サイクリング', 'ガソリン', 'ＥＮＥＯＳ', '駐車場', 'メトロ', 'タイムズ', 'ANA', 'JAL', '航空', 'チャージ']],
  ['housing', ['家賃', '電気', 'ガス料金', '水道', 'povo', 'ｐｏｖｏ', 'ドコモ', 'ａｕ', 'ソフトバンク', 'モバイル', 'ﾓﾊﾞｲﾙ', 'NHK', 'Wi-Fi', 'ネット', 'サブスク', 'Netflix', 'Spotify', 'プライム', '保険', '積立', '証券']],
  ['entertainment', ['映画', '遊園地', 'ゲーム', 'カラオケ', 'ライブ', 'ジム', 'シネマ', 'ディズニー', 'USJ', 'Switch', 'PlayStation', 'Steam']],
  ['shopping', ['パルコ', 'ユニクロ', 'ＺＡＲＡ', 'Amazon', 'ａｍａｚｏｎ', 'アマゾン', '楽天市場', '百貨店', 'デパート', '無印良品', 'ドンキ', 'ロフト', 'ヨドバシ', 'ビックカメラ', 'ＧＵ']],
];

// 全角英数字（ＳＢＩ、ｐｏｖｏ など）を半角に正規化してから比較するためのヘルパー。
// カード明細アプリは全角で表示することが多く、単純な toLowerCase() だけでは
// 半角キーワードと一致しないため。
function toComparableText(str) {
  return (str || '').normalize('NFKC').toLowerCase();
}

function guessCategoryFromMemo(memo) {
  if (!memo) return 'other';
  const normalized = toComparableText(memo).replace(/\s+/g, '');
  for (const [categoryId, keywords] of CATEGORY_KEYWORDS) {
    if (keywords.some((kw) => normalized.includes(toComparableText(kw)))) return categoryId;
  }
  return 'other';
}

// よく見かける店名・サービス名。OCRで多少崩れて読まれても（余分な文字・
// 半角全角の揺れなど）表記ゆれを吸収して、正式名称＋カテゴリに寄せるための対応表。
const KNOWN_MERCHANTS = [
  { match: 'パルコ', name: 'パルコ', category: 'shopping' },
  { match: 'ユニクロ', name: 'ユニクロ', category: 'shopping' },
  { match: 'gu', name: 'GU', category: 'shopping' },
  { match: '無印良品', name: '無印良品', category: 'shopping' },
  { match: 'ヨドバシ', name: 'ヨドバシカメラ', category: 'shopping' },
  { match: 'ビックカメラ', name: 'ビックカメラ', category: 'shopping' },
  { match: 'amazon', name: 'Amazon', category: 'shopping' },
  { match: '楽天市場', name: '楽天市場', category: 'shopping' },
  { match: 'cycling', name: 'Hello Cycling', category: 'transport' },
  { match: 'chargespot', name: 'ChargeSPOT', category: 'other' },
  { match: 'suica', name: 'Suica', category: 'transport' },
  { match: 'pasmo', name: 'PASMO', category: 'transport' },
  { match: 'povo', name: 'povo', category: 'housing' },
  { match: 'docomo', name: 'ドコモ', category: 'housing' },
  { match: 'ソフトバンク', name: 'ソフトバンク', category: 'housing' },
  { match: 'ラクテンモバイル', name: '楽天モバイル', category: 'housing' },
  { match: '楽天モバイル', name: '楽天モバイル', category: 'housing' },
  { match: 'netflix', name: 'Netflix', category: 'housing' },
  { match: 'spotify', name: 'Spotify', category: 'housing' },
  { match: 'sbi証券', name: 'SBI証券', category: 'housing' },
  { match: 'スターバックス', name: 'スターバックス', category: 'food' },
  { match: 'ドトール', name: 'ドトール', category: 'food' },
  { match: 'マクドナルド', name: 'マクドナルド', category: 'food' },
  { match: 'セブン', name: 'セブン-イレブン', category: 'food' },
  { match: 'ローソン', name: 'ローソン', category: 'food' },
  { match: 'ファミマ', name: 'ファミリーマート', category: 'food' },
  { match: 'ファミリーマート', name: 'ファミリーマート', category: 'food' },
];

/**
 * OCRで読み取った店名の表記ゆれ・ノイズ（アンダースコア、孤立した1文字、
 * 全角半角の揺れなど）を軽く整えつつ、既知の店名リストに近ければ
 * 正式名称＋カテゴリに置き換える。
 */
function cleanMerchantName(rawMemo) {
  const base = (rawMemo || '').replace(/[_＿]/g, ' ').replace(/\s+/g, ' ').trim();
  const compact = toComparableText(base).replace(/\s+/g, '');

  for (const merchant of KNOWN_MERCHANTS) {
    if (compact.includes(toComparableText(merchant.match).replace(/\s+/g, ''))) {
      return { name: merchant.name, category: merchant.category };
    }
  }

  // 一致しない場合も、行末に紛れ込みがちな孤立した1文字（アイコンの誤読など）だけ除く
  const trimmed = base.replace(/\s+[ぁ-んァ-ヶ]$/u, '').trim() || base;
  return { name: trimmed, category: guessCategoryFromMemo(trimmed) };
}

// 初回起動時のサンプルデータ（保存データが無いときのみ使われる）
const DEFAULT_CARDS = [
  {
    id: 'card-1',
    name: 'メインゴールドカード',
    brand: 'VISA',
    last4: '4821',
    number: '4532 0151 1283 4821',
    holderName: 'TARO YAMADA',
    expiry: '08/29',
    cvv: '412',
    theme: 'purple',
    limit: 300000,
    billingDay: '15',
    paymentDay: '10',
  },
  {
    id: 'card-2',
    name: '楽天カード',
    brand: 'Mastercard',
    last4: '9102',
    number: '5412 7534 8890 9102',
    holderName: 'TARO YAMADA',
    expiry: '11/28',
    cvv: '256',
    theme: 'sunset',
    limit: 200000,
    billingDay: '末日',
    paymentDay: '27',
  },
  {
    id: 'card-3',
    name: '交通系JCBカード',
    brand: 'JCB',
    last4: '3310',
    number: '3528 1147 9902 3310',
    holderName: 'TARO YAMADA',
    expiry: '03/27',
    cvv: '789',
    theme: 'blue',
    limit: 100000,
    billingDay: '末日',
    paymentDay: '10',
  },
];

const DEFAULT_TRANSACTIONS = [
  // 4月〜6月（月別推移のサンプル用）
  { id: 't-101', cardId: 'card-1', amount: 68000, date: '2026-04-10', category: 'shopping', memo: '新生活用品' },
  { id: 't-102', cardId: 'card-2', amount: 21000, date: '2026-04-20', category: 'food', memo: '' },
  { id: 't-103', cardId: 'card-1', amount: 74000, date: '2026-05-08', category: 'housing', memo: '' },
  { id: 't-104', cardId: 'card-2', amount: 26000, date: '2026-05-24', category: 'entertainment', memo: '' },
  { id: 't-105', cardId: 'card-1', amount: 61000, date: '2026-06-12', category: 'food', memo: '' },
  { id: 't-106', cardId: 'card-3', amount: 15000, date: '2026-06-18', category: 'transport', memo: '' },
  // 7月
  { id: 't-7', cardId: 'card-1', amount: 28000, date: '2026-07-18', category: 'shopping', memo: '夏服購入' },
  { id: 't-8', cardId: 'card-2', amount: 15000, date: '2026-07-22', category: 'food', memo: '外食・飲み会' },
  // 8月
  { id: 't-1', cardId: 'card-1', amount: 14800, date: '2026-08-02', category: 'food', memo: '週末スーパー買い物' },
  { id: 't-2', cardId: 'card-2', amount: 32000, date: '2026-08-05', category: 'shopping', memo: 'スニーカー新調' },
  { id: 't-3', cardId: 'card-3', amount: 8500, date: '2026-08-08', category: 'transport', memo: 'チャージ＆新幹線チケット' },
  { id: 't-4', cardId: 'card-1', amount: 9800, date: '2026-08-10', category: 'housing', memo: '通信費・サブスク' },
  { id: 't-5', cardId: 'card-2', amount: 12400, date: '2026-08-12', category: 'entertainment', memo: '友人とのディナー' },
  { id: 't-6', cardId: 'card-1', amount: 4500, date: '2026-08-15', category: 'food', memo: 'カフェ・ランチ' },
];

function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function monthRange(startKey, endKey) {
  const [sy, sm] = startKey.split('-').map(Number);
  const [ey, em] = endKey.split('-').map(Number);
  const out = [];
  let y = sy;
  let m = sm;
  while (y < ey || (y === ey && m <= em)) {
    out.push(`${y}-${String(m).padStart(2, '0')}`);
    m += 1;
    if (m > 12) { m = 1; y += 1; }
  }
  return out;
}

/** Continuous, zero-filled monthly totals for a set of transactions. */
function buildMonthlySeries(txs) {
  if (!txs.length) return [];
  const sums = new Map();
  let min = null;
  let max = null;
  txs.forEach((t) => {
    const mk = t.date.slice(0, 7);
    sums.set(mk, (sums.get(mk) || 0) + Number(t.amount));
    if (!min || mk < min) min = mk;
    if (!max || mk > max) max = mk;
  });
  return monthRange(min, max).map((k) => ({
    key: k,
    xLabel: `${Number(k.slice(5, 7))}月`,
    fullLabel: `${k.slice(0, 4)}年${Number(k.slice(5, 7))}月`,
    value: sums.get(k) || 0,
  }));
}

function formatCardNumber(number) {
  const digits = (number || '').replace(/\D/g, '');
  if (!digits) return '未登録';
  return digits.replace(/(.{4})(?=.)/g, '$1 ');
}

function maskCardNumber(number, last4) {
  const digits = (number || '').replace(/\D/g, '');
  const tail = digits ? digits.slice(-4) : (last4 || '0000');
  return `•••• •••• •••• ${tail}`;
}

// 日本語カテゴリ名 → カテゴリID の対応表（インポート時に使用）
const CATEGORY_NAME_TO_ID = CATEGORIES.reduce((map, c) => {
  map[c.name] = c.id;
  return map;
}, {});

function resolveCategoryId(value) {
  if (!value) return 'other';
  if (CATEGORIES.some((c) => c.id === value)) return value;
  if (CATEGORY_NAME_TO_ID[value]) return CATEGORY_NAME_TO_ID[value];
  return 'other';
}

function resolveDate(value) {
  if (!value) return new Date().toISOString().split('T')[0];
  // "2026年8月10日" のような表記もざっくり受け付ける
  const m = String(value).match(/(\d{4})[/\-年](\d{1,2})[/\-月](\d{1,2})/);
  if (m) {
    const [, y, mo, d] = m;
    return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  return value;
}

// ---------- 画像（スクリーンショット）からの明細読み取り ----------

function parseAmountToken(str) {
  const digits = str.replace(/[^\d]/g, '');
  return digits ? Number(digits) : null;
}

function parseDateToken(token, fallbackYear) {
  // 2026/08/10, 2026-08-10, 2026年8月10日
  let m = token.match(/(\d{4})[/\-年](\d{1,2})[/\-月](\d{1,2})日?/);
  if (m) {
    const [, y, mo, d] = m;
    return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  // 26.07.01 のような西暦下2桁・ドット区切り（クレジットカード明細アプリでよく見る表記）
  m = token.match(/^(\d{2})\.(\d{1,2})\.(\d{1,2})$/);
  if (m) {
    const [, yy, mo, d] = m;
    return `${2000 + Number(yy)}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  // 8/10, 8月10日（年なし）
  m = token.match(/^(\d{1,2})[/月](\d{1,2})日?$/);
  if (m) {
    const [, mo, d] = m;
    return `${fallbackYear}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  return null;
}

const OCR_DATE_REGEX = /(\d{4}[/\-年]\d{1,2}[/\-月]\d{1,2}日?|\d{2}\.\d{1,2}\.\d{1,2}|\d{1,2}[/月]\d{1,2}日)/;
const OCR_AMOUNT_REGEX = /[¥￥]\s?[\d,]{2,}|[\d,]{3,}\s?円/;

/**
 * OCR前の画像前処理。スマホのスクリーンショットは見た目の解像度は高くても、
 * 実際の文字の高さ（ピクセル数）が小さく、Tesseractの認識精度が落ちやすい。
 * 十分な文字高さになるまで拡大し、グレースケール化＋コントラスト強調してから渡す。
 * 失敗した場合は元のファイルをそのまま使う（呼び出し側でフォールバック）。
 */
async function preprocessImageForOcr(file) {
  const img = await createImageBitmap(file);
  const targetWidth = 1800;
  const scale = Math.min(3, Math.max(1, targetWidth / img.width));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  // グレースケール化 + 簡易コントラスト強調
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const { data } = imageData;
  const contrast = 1.35;
  for (let i = 0; i < data.length; i += 4) {
    const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
    const adjusted = Math.min(255, Math.max(0, (gray - 128) * contrast + 128));
    data[i] = adjusted;
    data[i + 1] = adjusted;
    data[i + 2] = adjusted;
  }
  ctx.putImageData(imageData, 0, 0);

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('toBlob failed'))), 'image/png');
  });
}

/**
 * OCRの単語＋座標から、画面上の「行」を再構成する。
 * カード明細アプリは店名／金額が同じ横位置、日付／回数がその下の行、
 * というレイアウトが多く、素の認識テキストの並び順だけでは崩れやすいため、
 * 単語の縦位置でグルーピングし直してから読む。
 */
function groupWordsIntoRows(words) {
  const clean = (words || [])
    .filter((w) => w.text && w.text.trim())
    .map((w) => ({
      text: w.text.trim(),
      x: w.bbox.x0,
      y: (w.bbox.y0 + w.bbox.y1) / 2,
      h: Math.max(w.bbox.y1 - w.bbox.y0, 1),
    }));
  if (!clean.length) return [];

  clean.sort((a, b) => a.y - b.y);
  const avgH = clean.reduce((s, w) => s + w.h, 0) / clean.length;
  const threshold = avgH * 0.6;

  const rows = [];
  let current = [clean[0]];
  let currentY = clean[0].y;
  for (let i = 1; i < clean.length; i++) {
    const w = clean[i];
    if (Math.abs(w.y - currentY) <= threshold) {
      current.push(w);
      currentY = current.reduce((s, x) => s + x.y, 0) / current.length;
    } else {
      rows.push(current);
      current = [w];
      currentY = w.y;
    }
  }
  rows.push(current);

  return rows.map((row) => row.sort((a, b) => a.x - b.x).map((w) => w.text).join(' '));
}

/**
 * 行の配列から、日付＋金額の組を推測して候補リストを作る。
 * あくまで「たたき台」— 呼び出し側で必ず確認・編集させる前提。
 * 店名＋金額が同じ行、日付が別行（前後どちらもありうる）というレイアウトに対応する。
 */
function parseTransactionsFromRows(rawLines) {
  const year = new Date().getFullYear();
  const lines = rawLines.map((l) => l.trim()).filter(Boolean);

  const candidates = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const dateMatch = line.match(OCR_DATE_REGEX);
    if (!dateMatch) continue;
    const date = parseDateToken(dateMatch[0], year);
    if (!date) continue;

    let amount = null;
    let memoSource = '';

    const sameLineAmt = line.match(OCR_AMOUNT_REGEX);
    if (sameLineAmt) {
      amount = parseAmountToken(sameLineAmt[0]);
      memoSource = line.replace(dateMatch[0], '').replace(sameLineAmt[0], '').trim();
    } else {
      // 店名＋金額は前の行にあることが多いレイアウトを優先しつつ、後ろの行も見る
      for (const j of [i - 1, i + 1, i - 2, i + 2]) {
        if (j < 0 || j >= lines.length) continue;
        const amtMatch = lines[j].match(OCR_AMOUNT_REGEX);
        if (amtMatch) {
          amount = parseAmountToken(amtMatch[0]);
          memoSource = lines[j].replace(amtMatch[0], '').trim();
          break;
        }
      }
    }
    if (!amount) continue;

    const rawMemo = memoSource.replace(/[|•·]/g, '').trim().slice(0, 40);
    const { name: memo, category } = cleanMerchantName(rawMemo);
    candidates.push({
      id: `ocr-${i}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      date,
      amount,
      category,
      memo,
    });
  }
  return candidates.slice(0, 50);
}

export default function App() {
  // 現在選択されている年月 (YYYY-MM) — 実際の今日の日付から算出
  const [currentMonth, setCurrentMonth] = useState(currentMonthKey);
  const [activeTab, setActiveTab] = useState('dashboard'); // 'dashboard' | 'transactions' | 'cards'

  // モーダルの状態
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);
  const [isAddCardOpen, setIsAddCardOpen] = useState(false);

  // クレジットカードデータ（保存データがあればそれを、無ければサンプルを初期値に）
  const [cards, setCards] = useState(() => loadList(STORAGE_KEYS.cards, DEFAULT_CARDS));

  // 利用明細データ
  const [transactions, setTransactions] = useState(() => loadList(STORAGE_KEYS.transactions, DEFAULT_TRANSACTIONS));

  // データが変わるたびにブラウザに自動保存
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.cards, JSON.stringify(cards));
  }, [cards]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.transactions, JSON.stringify(transactions));
  }, [transactions]);

  // フィルター用ステート（明細タブ）
  const [filterCardId, setFilterCardId] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');

  // 月別推移グラフのステート
  const [trendMode, setTrendMode] = useState('total'); // 'total' | 'card'
  const [trendCardId, setTrendCardId] = useState('');

  // 新規明細フォームのステート
  const [newTx, setNewTx] = useState({
    cardId: cards[0]?.id || '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    category: 'food',
    memo: '',
  });

  // 新規カードフォームのステート
  const [newCard, setNewCard] = useState({
    name: '',
    brand: 'VISA',
    number: '',
    holderName: '',
    expiry: '',
    cvv: '',
    theme: 'purple',
    limit: 200000,
    billingDay: '末日',
    paymentDay: '27',
  });

  // カード番号・有効期限・セキュリティコードを表示中のカードID
  const [revealedCards, setRevealedCards] = useState(() => new Set());
  const toggleCardReveal = (cardId) => {
    setRevealedCards((prev) => {
      const next = new Set(prev);
      if (next.has(cardId)) next.delete(cardId);
      else next.add(cardId);
      return next;
    });
  };

  // --- 月の切り替え処理 ---
  const handleMonthChange = (offset) => {
    const [year, month] = currentMonth.split('-').map(Number);
    const date = new Date(year, month - 1 + offset, 1);
    const newYear = date.getFullYear();
    const newMonth = String(date.getMonth() + 1).padStart(2, '0');
    setCurrentMonth(`${newYear}-${newMonth}`);
  };

  // 表示用の年月フォーマット（例: 2026年 8月）
  const formattedMonth = useMemo(() => {
    const [year, month] = currentMonth.split('-');
    return `${year}年 ${parseInt(month, 10)}月`;
  }, [currentMonth]);

  // --- 計算系ロジック ---
  // 当月の全明細
  const monthlyTransactions = useMemo(() => {
    return transactions.filter((t) => t.date.startsWith(currentMonth));
  }, [transactions, currentMonth]);

  // 当月の合計利用額
  const totalMonthlyAmount = useMemo(() => {
    return monthlyTransactions.reduce((sum, t) => sum + Number(t.amount), 0);
  }, [monthlyTransactions]);

  // カード別の当月利用額集計
  const cardMonthlyStats = useMemo(() => {
    return cards.map((card) => {
      const cardTxs = monthlyTransactions.filter((t) => t.cardId === card.id);
      const spent = cardTxs.reduce((sum, t) => sum + Number(t.amount), 0);
      const percentage = card.limit ? Math.min(Math.round((spent / card.limit) * 100), 100) : 0;
      return { ...card, spent, percentage };
    });
  }, [cards, monthlyTransactions]);

  // カテゴリ別支出集計
  const categoryStats = useMemo(() => {
    const map = {};
    CATEGORIES.forEach((c) => { map[c.id] = 0; });

    monthlyTransactions.forEach((t) => {
      if (map[t.category] !== undefined) {
        map[t.category] += Number(t.amount);
      } else {
        map.other = (map.other || 0) + Number(t.amount);
      }
    });

    return CATEGORIES.map((cat) => ({
      ...cat,
      amount: map[cat.id] || 0,
      percentage: totalMonthlyAmount > 0 ? Math.round(((map[cat.id] || 0) / totalMonthlyAmount) * 100) : 0,
    })).sort((a, b) => b.amount - a.amount);
  }, [monthlyTransactions, totalMonthlyAmount]);

  // 月別支出推移（全期間・全カード or 特定カード）
  const trendSeries = useMemo(() => {
    const activeCardId = trendCardId || cards[0]?.id || '';
    const relevant = trendMode === 'card'
      ? transactions.filter((t) => t.cardId === activeCardId)
      : transactions;
    return buildMonthlySeries(relevant);
  }, [transactions, trendMode, trendCardId, cards]);

  // 前月比（月別推移カードのすぐ下で使う簡易サマリー）
  const monthOverMonth = useMemo(() => {
    const lastKey = (() => {
      const [y, m] = currentMonth.split('-').map(Number);
      const d = new Date(y, m - 2, 1);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    })();
    const lastTotal = transactions
      .filter((t) => t.date.startsWith(lastKey))
      .reduce((sum, t) => sum + Number(t.amount), 0);
    if (lastTotal === 0) return null;
    const diff = totalMonthlyAmount - lastTotal;
    return { lastTotal, diff, pct: (diff / lastTotal) * 100 };
  }, [transactions, currentMonth, totalMonthlyAmount]);

  // 明細一覧フィルター適用
  const filteredTransactions = useMemo(() => {
    return monthlyTransactions.filter((t) => {
      const matchCard = filterCardId === 'all' || t.cardId === filterCardId;
      const matchCat = filterCategory === 'all' || t.category === filterCategory;
      return matchCard && matchCat;
    }).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [monthlyTransactions, filterCardId, filterCategory]);

  // --- アクションハンドラー ---
  const handleAddTransaction = (e) => {
    e.preventDefault();
    if (!newTx.amount || !newTx.cardId) return;

    const newEntry = {
      id: `t-${Date.now()}`,
      cardId: newTx.cardId,
      amount: Number(newTx.amount),
      date: newTx.date,
      category: newTx.category,
      memo: newTx.memo || '利用明細',
    };

    setTransactions([newEntry, ...transactions]);
    setIsAddTransactionOpen(false);

    // フォームリセット
    setNewTx({
      cardId: cards[0]?.id || '',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      category: 'food',
      memo: '',
    });
  };

  const handleDeleteTransaction = (id) => {
    if (confirm('この利用明細を削除しますか？')) {
      setTransactions(transactions.filter((t) => t.id !== id));
    }
  };

  const handleAddCard = (e) => {
    e.preventDefault();
    if (!newCard.name) return;

    const digits = newCard.number.replace(/\D/g, '');
    const createdCard = {
      id: `card-${Date.now()}`,
      ...newCard,
      limit: Number(newCard.limit) || 0,
      last4: digits ? digits.slice(-4) : '0000',
    };

    setCards([...cards, createdCard]);
    setIsAddCardOpen(false);

    // フォームリセット
    setNewCard({
      name: '',
      brand: 'VISA',
      number: '',
      holderName: '',
      expiry: '',
      cvv: '',
      theme: 'purple',
      limit: 200000,
      billingDay: '末日',
      paymentDay: '27',
    });
  };

  const handleDeleteCard = (cardId) => {
    if (cards.length <= 1) {
      alert('最低1枚のカードが必要です。');
      return;
    }
    if (confirm('このカードを削除すると、関連する明細も確認できなくなる可能性があります。削除しますか？')) {
      setCards(cards.filter((c) => c.id !== cardId));
      setTransactions(transactions.filter((t) => t.cardId !== cardId));
    }
  };

  // --- 書き出し / 読み込み ---
  // Claude Artifact の中で開かれている場合は外部ネットワークが遮断されるため、
  // 画像OCR（Tesseract.js を CDN から取得）は使えない。JSONの読み込みのみ提供する。
  const inCapabilityHost = !!(window.claude && typeof window.claude.use === 'function');

  const importFileRef = useRef(null);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrReview, setOcrReview] = useState(null); // { candidates: [...], cardId }
  const [ocrRawText, setOcrRawText] = useState(null); // 自動検出できなかった時、読み取れた生テキストを見せる

  const handleExport = async () => {
    const data = { exportedAt: new Date().toISOString(), cards, transactions };
    const json = JSON.stringify(data, null, 2);
    const filename = `cardmanager-backup-${new Date().toISOString().slice(0, 10)}.json`;

    if (inCapabilityHost) {
      try {
        const downloads = await window.claude.use('downloads');
        if (downloads) {
          await downloads.save({ filename, data: json });
        } else {
          alert('この環境では書き出し機能を利用できません。');
        }
      } catch (err) {
        if (err && err.code !== 'declined') {
          console.error(err);
          alert('書き出しに失敗しました。');
        }
      }
      return;
    }

    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => importFileRef.current?.click();

  // カードは「名前」で既存カードと突き合わせる。無ければ新規作成して cards に足す。
  const buildCardResolver = (baseCards) => {
    const nextCards = [...baseCards];
    const findOrCreateCardId = (nameOrId, extra = {}) => {
      if (!nameOrId) return nextCards[0]?.id || null;
      const byId = nextCards.find((c) => c.id === nameOrId);
      if (byId) return byId.id;
      const byName = nextCards.find((c) => c.name === nameOrId);
      if (byName) return byName.id;
      const created = {
        id: `card-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: nameOrId,
        brand: extra.brand || 'VISA',
        last4: extra.last4 || (extra.number || '').replace(/\D/g, '').slice(-4) || '0000',
        number: extra.number || '',
        holderName: extra.holderName || '',
        expiry: extra.expiry || '',
        cvv: extra.cvv || '',
        theme: extra.theme && CARD_THEMES[extra.theme] ? extra.theme : 'purple',
        limit: Number(extra.limit) || 0,
        billingDay: extra.billingDay || '末日',
        paymentDay: extra.paymentDay || '27',
      };
      nextCards.push(created);
      return created.id;
    };
    return { nextCards, findOrCreateCardId };
  };

  const handleImportJsonFile = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        const incomingCards = Array.isArray(data.cards) ? data.cards : [];
        const incomingTxs = Array.isArray(data.transactions) ? data.transactions : [];
        if (!incomingCards.length && !incomingTxs.length) throw new Error('empty');

        const { nextCards, findOrCreateCardId } = buildCardResolver(cards);
        incomingCards.forEach((c) => findOrCreateCardId(c.name || c.cardName, c));

        const newTxs = incomingTxs
          .map((t) => {
            const cardId = findOrCreateCardId(t.cardId || t.cardName || t.card);
            if (!cardId || !t.amount) return null;
            return {
              id: `t-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
              cardId,
              amount: Number(t.amount),
              date: resolveDate(t.date),
              category: resolveCategoryId(t.category),
              memo: t.memo || '',
            };
          })
          .filter(Boolean);

        setCards(nextCards);
        setTransactions([...newTxs, ...transactions]);
        alert(`${newTxs.length}件の明細を読み込みました。`);
      } catch (err) {
        console.error(err);
        alert('ファイルの読み込みに失敗しました。正しいバックアップ／インポート用ファイルか確認してください。');
      }
    };
    reader.readAsText(file);
  };

  const handleImportImageFile = async (file) => {
    setOcrLoading(true);
    try {
      let ocrInput = file;
      try {
        ocrInput = await preprocessImageForOcr(file);
      } catch (preErr) {
        console.warn('画像の前処理に失敗したため、元の画像のまま読み取ります', preErr);
      }

      const { createWorker, PSM } = await import('tesseract.js');
      const worker = await createWorker('jpn');
      // カード明細は縦一列のリスト状レイアウトなので、単一段組みを仮定するPSMの方が
      // デフォルト（自動レイアウト解析）より安定して読めることが多い。
      await worker.setParameters({ tessedit_pageseg_mode: PSM.SINGLE_COLUMN });
      const { data } = await worker.recognize(ocrInput, {}, { text: true, blocks: true });
      await worker.terminate();

      // 単語の座標から画面上の行を再構成して読む（店名と金額が横並び、日付は
      // その下の行、というカード明細アプリのレイアウト崩れに強くするため）。
      // 座標データの形が想定と違っても、素の認識テキストの行分割に必ずフォールバックする。
      let candidates = [];
      try {
        const words = (data.blocks || [])
          .flatMap((b) => b.paragraphs || [])
          .flatMap((p) => p.lines || [])
          .flatMap((l) => l.words || []);
        const rows = groupWordsIntoRows(words);
        if (rows.length) candidates = parseTransactionsFromRows(rows);
      } catch (rowErr) {
        console.warn('行の再構成に失敗したため、通常のテキスト分割にフォールバックします', rowErr);
      }
      if (!candidates.length) {
        candidates = parseTransactionsFromRows((data.text || '').split('\n'));
      }
      if (!candidates.length) {
        setOcrRawText(data.text || '（文字を読み取れませんでした）');
        return;
      }
      setOcrReview({ candidates, cardId: cards[0]?.id || '' });
    } catch (err) {
      console.error(err);
      alert('画像の読み取りに失敗しました。通信環境をご確認のうえ、もう一度お試しください。');
    } finally {
      setOcrLoading(false);
    }
  };

  const handleImportFile = (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (file.type.startsWith('image/')) {
      handleImportImageFile(file);
    } else {
      handleImportJsonFile(file);
    }
  };

  const updateOcrCandidate = (idx, patch) => {
    setOcrReview((prev) => (prev ? {
      ...prev,
      candidates: prev.candidates.map((c, i) => (i === idx ? { ...c, ...patch } : c)),
    } : prev));
  };
  const removeOcrCandidate = (idx) => {
    setOcrReview((prev) => (prev ? {
      ...prev,
      candidates: prev.candidates.filter((_, i) => i !== idx),
    } : prev));
  };
  const handleConfirmOcrImport = () => {
    if (!ocrReview) return;
    const newTxs = ocrReview.candidates
      .filter((c) => c.amount && c.date)
      .map((c) => ({
        id: `t-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        cardId: ocrReview.cardId,
        amount: Number(c.amount),
        date: c.date,
        category: c.category,
        memo: c.memo,
      }));
    setTransactions([...newTxs, ...transactions]);
    setOcrReview(null);
    alert(`${newTxs.length}件の明細を追加しました。`);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased selection:bg-indigo-500 selection:text-white">

      {/* 1. トップヘッダー */}
      <header className="sticky top-0 z-30 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 px-4 py-3 sm:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-xl shadow-lg shadow-indigo-500/20">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg sm:text-xl tracking-tight text-white flex items-center gap-2">
                CardManager <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 font-medium">Pro</span>
              </h1>
              <p className="text-xs text-slate-400 hidden sm:block">クレジットカード利用額・月別管理</p>
            </div>
          </div>

          {/* 明細追加ボタン */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (cards.length > 0) {
                  setNewTx((prev) => ({ ...prev, cardId: cards[0].id }));
                }
                setIsAddTransactionOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all duration-200 shadow-lg shadow-indigo-600/30 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>利用を記録</span>
            </button>
          </div>
        </div>
      </header>

      {/* 2. 月切替ナビゲーションバー */}
      <div className="bg-slate-800/50 border-b border-slate-800/80 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <button
            onClick={() => handleMonthChange(-1)}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="前月"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-indigo-400" />
            <span className="text-lg font-bold tracking-wide text-white">{formattedMonth}</span>
          </div>

          <button
            onClick={() => handleMonthChange(1)}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="次月"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 3. メインコンテンツ領域 */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 space-y-6">

        {/* ナビゲーションタブ */}
        <div className="flex bg-slate-800/80 p-1.5 rounded-2xl border border-slate-700/50 max-w-md mx-auto sm:mx-0">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex-1 py-2 px-1.5 sm:px-3 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-1 sm:gap-2 ${
              activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PieChart className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">ダッシュボード</span>
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex-1 py-2 px-1.5 sm:px-3 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-1 sm:gap-2 ${
              activeTab === 'transactions' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <List className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">明細一覧 ({monthlyTransactions.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('cards')}
            className={`flex-1 py-2 px-1.5 sm:px-3 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-1 sm:gap-2 ${
              activeTab === 'cards' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wallet className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">カード管理 ({cards.length})</span>
          </button>
        </div>

        {/* --- タブ 1: ダッシュボード --- */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-fadeIn">

            {/* ハイライトサマリーカード */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-5 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <TrendingUp className="w-24 h-24 text-indigo-400" />
                </div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">今月の合計利用額</p>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-3xl sm:text-4xl font-extrabold text-white">
                    ¥{totalMonthlyAmount.toLocaleString()}
                  </span>
                </div>
                {monthOverMonth ? (
                  <p className={`mt-2 text-xs font-semibold ${monthOverMonth.diff > 0 ? 'text-rose-400' : monthOverMonth.diff < 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {monthOverMonth.diff > 0 ? '▲' : monthOverMonth.diff < 0 ? '▼' : '―'}
                    {' '}
                    {monthOverMonth.diff >= 0 ? '+' : '−'}¥{Math.abs(monthOverMonth.diff).toLocaleString()}
                    {' '}
                    （{monthOverMonth.diff >= 0 ? '+' : '−'}{Math.abs(monthOverMonth.pct).toFixed(1)}%） 先月比
                  </p>
                ) : (
                  <p className="mt-2 text-xs text-slate-400">
                    登録カード {cards.length} 枚の総支払予定額
                  </p>
                )}
              </div>

              <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-5 shadow-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">今月の決済件数</p>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-3xl sm:text-4xl font-extrabold text-indigo-400">
                    {monthlyTransactions.length}
                  </span>
                  <span className="text-slate-400 text-sm">件</span>
                </div>
                <p className="mt-2 text-xs text-slate-400">
                  平均決済額: ¥{monthlyTransactions.length ? Math.round(totalMonthlyAmount / monthlyTransactions.length).toLocaleString() : 0}
                </p>
              </div>

              <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-5 shadow-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">最も利用したカード</p>
                {cardMonthlyStats.length > 0 ? (() => {
                  const topCard = [...cardMonthlyStats].sort((a, b) => b.spent - a.spent)[0];
                  return (
                    <div className="mt-2">
                      <div className="text-lg font-bold text-white truncate">{topCard.name}</div>
                      <div className="text-indigo-400 font-semibold mt-0.5">
                        ¥{topCard.spent.toLocaleString()}
                      </div>
                    </div>
                  );
                })() : (
                  <p className="mt-2 text-slate-500 text-sm">データがありません</p>
                )}
              </div>
            </div>

            {/* 月別支出推移 */}
            <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-5 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-1">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-indigo-400" />
                  月別支出推移
                </h2>
                <div className="flex items-center gap-2">
                  <div className="flex bg-slate-900/70 p-1 rounded-lg border border-slate-700/60">
                    <button
                      onClick={() => setTrendMode('total')}
                      className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                        trendMode === 'total' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      全カード合計
                    </button>
                    <button
                      onClick={() => setTrendMode('card')}
                      className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                        trendMode === 'card' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      カード別
                    </button>
                  </div>
                  {trendMode === 'card' && (
                    <select
                      value={trendCardId || cards[0]?.id || ''}
                      onChange={(e) => setTrendCardId(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-lg text-xs px-2.5 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      {cards.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  )}
                </div>
              </div>
              <TrendChart series={trendSeries} />
            </div>

            {/* クレジットカード別利用額（カードデザイン表示） */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-indigo-400" />
                  カード別利用状況
                </h2>
                <button
                  onClick={() => setIsAddCardOpen(true)}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> カードを追加
                </button>
              </div>

              {cards.length === 0 ? (
                <div className="bg-slate-800/50 rounded-2xl p-8 text-center border border-dashed border-slate-700">
                  <p className="text-slate-400 text-sm">クレジットカードが登録されていません</p>
                  <button
                    onClick={() => setIsAddCardOpen(true)}
                    className="mt-3 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-medium"
                  >
                    カードを追加する
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {cardMonthlyStats.map((card) => {
                    const theme = CARD_THEMES[card.theme] || CARD_THEMES.purple;
                    return (
                      <div
                        key={card.id}
                        className={`rounded-2xl p-5 shadow-xl border ${theme.bg} ${theme.border} relative flex flex-col justify-center gap-4 h-52 transition-transform duration-200 hover:-translate-y-1`}
                      >
                        {/* カード上部 */}
                        <div className="flex justify-between items-start">
                          <div>
                            <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${theme.badge}`}>
                              {card.brand}
                            </span>
                            <h3 className="font-bold text-white text-sm mt-1.5 truncate max-w-[160px]">
                              {card.name}
                            </h3>
                          </div>
                          <span className="font-mono text-xs text-white/70">•••• {card.last4}</span>
                        </div>

                        {/* カード中央: 利用金額 */}
                        <div>
                          <span className="text-xs text-white/70">今月の利用額</span>
                          <div className="text-xl font-black text-white tracking-tight">
                            ¥{card.spent.toLocaleString()}
                          </div>
                        </div>

                        {/* カード下部: ゲージ＆締め日情報 */}
                        <div className="space-y-1.5">
                          {card.limit > 0 && (
                            <div>
                              <div className="flex justify-between text-[10px] text-white/80 mb-1">
                                <span>利用枠</span>
                                <span>{card.percentage}% (上限: ¥{card.limit.toLocaleString()})</span>
                              </div>
                              <div className="w-full h-1.5 bg-black/30 rounded-full overflow-hidden backdrop-blur-sm">
                                <div
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    card.percentage > 80 ? 'bg-red-400' : 'bg-white'
                                  }`}
                                  style={{ width: `${Math.min(card.percentage, 100)}%` }}
                                />
                              </div>
                            </div>
                          )}
                          <div className="flex justify-between items-center text-[10px] text-white/60 pt-0.5">
                            <span>締日: {card.billingDay}</span>
                            <span>支払日: 毎月{card.paymentDay}日</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* カテゴリ別内訳 */}
            <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-5 shadow-xl">
              <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Tag className="w-5 h-5 text-indigo-400" />
                カテゴリ別支出内訳
              </h2>

              {totalMonthlyAmount === 0 ? (
                <p className="text-slate-400 text-sm text-center py-6">この月の利用明細はありません。</p>
              ) : (
                <div className="space-y-3">
                  {categoryStats.filter((c) => c.amount > 0).map((cat) => {
                    const IconComponent = cat.icon;
                    return (
                      <div key={cat.id} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center space-x-2">
                            <div className={`p-1.5 rounded-lg bg-slate-700 ${cat.color.split(' ')[1]}`}>
                              <IconComponent className="w-4 h-4" />
                            </div>
                            <span className="font-medium text-slate-200">{cat.name}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-bold text-white">¥{cat.amount.toLocaleString()}</span>
                            <span className="text-xs text-slate-400 ml-2">({cat.percentage}%)</span>
                          </div>
                        </div>
                        {/* プログレスバー */}
                        <div className="w-full bg-slate-700/50 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${cat.color.split(' ')[0]}`}
                            style={{ width: `${cat.percentage}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>
        )}

        {/* --- タブ 2: 利用明細一覧 --- */}
        {activeTab === 'transactions' && (
          <div className="space-y-4 animate-fadeIn">

            {/* フィルター・検索バー */}
            <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-4 flex flex-wrap gap-3 items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-slate-300">
                <Filter className="w-4 h-4 text-indigo-400" />
                <span className="font-medium">絞り込み:</span>
              </div>

              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                {/* カード絞り込み */}
                <select
                  value={filterCardId}
                  onChange={(e) => setFilterCardId(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">すべてのカード</option>
                  {cards.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>

                {/* カテゴリ絞り込み */}
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">すべてのカテゴリ</option>
                  {CATEGORIES.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* 書き出し・読み込み */}
            <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-slate-400">
                {inCapabilityHost
                  ? 'データのバックアップ、またはバックアップ用JSONファイルの読み込み'
                  : 'データのバックアップ、または明細のスクリーンショットを直接読み込めます'}
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleExport}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs sm:text-sm font-medium hover:bg-slate-700/60 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  書き出し
                </button>
                <button
                  type="button"
                  onClick={handleImportClick}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs sm:text-sm font-medium hover:bg-slate-700/60 transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  読み込み
                </button>
                <input
                  ref={importFileRef}
                  type="file"
                  accept={inCapabilityHost ? 'application/json' : 'application/json,image/*'}
                  onChange={handleImportFile}
                  className="sr-only"
                />
              </div>
            </div>

            {/* 明細リスト */}
            <div className="bg-slate-800/90 border border-slate-700/60 rounded-2xl overflow-hidden shadow-xl">
              {filteredTransactions.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  該当する明細がありません。
                </div>
              ) : (
                <div className="divide-y divide-slate-700/50">
                  {filteredTransactions.map((tx) => {
                    const card = cards.find((c) => c.id === tx.cardId);
                    const categoryObj = CATEGORIES.find((c) => c.id === tx.category) || CATEGORIES[CATEGORIES.length - 1];
                    const IconComponent = categoryObj.icon;

                    return (
                      <div
                        key={tx.id}
                        className="p-4 hover:bg-slate-700/30 transition-colors flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center space-x-3.5 min-w-0">
                          <div className={`p-2.5 rounded-xl bg-slate-700 ${categoryObj.color.split(' ')[1]} shrink-0`}>
                            <IconComponent className="w-5 h-5" />
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-white text-sm sm:text-base truncate">
                              {tx.memo}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                              <span>{tx.date}</span>
                              <span>•</span>
                              <span className="text-slate-300 font-medium">{card?.name || '削除されたカード'}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-3 shrink-0">
                          <span className="font-bold text-white text-base sm:text-lg">
                            ¥{Number(tx.amount).toLocaleString()}
                          </span>
                          <button
                            onClick={() => handleDeleteTransaction(tx.id)}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-lg transition-colors"
                            title="削除"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>
        )}

        {/* --- タブ 3: クレジットカード管理 --- */}
        {activeTab === 'cards' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-lg font-bold text-white">登録クレジットカード一覧</h2>
                <p className="text-xs text-slate-400">カードの管理・追加・削除を行えます</p>
              </div>
              <button
                onClick={() => setIsAddCardOpen(true)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-medium flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>新規カード追加</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {cards.map((card) => {
                const theme = CARD_THEMES[card.theme] || CARD_THEMES.purple;
                return (
                  <div
                    key={card.id}
                    className="bg-slate-800/90 border border-slate-700/60 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4"
                  >
                    {/* カード上部表示 */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`p-3 rounded-xl ${theme.bg} shadow-md`}>
                          <CreditCard className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="font-bold text-white text-base">{card.name}</h3>
                          <p className="text-xs text-slate-400">{card.brand} •••• {card.last4}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDeleteCard(card.id)}
                        className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-xl transition-colors"
                        title="カード削除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* カード番号・有効期限・セキュリティコード・名義 */}
                    <div className="bg-slate-900/50 p-3.5 rounded-xl border border-slate-700/40 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5" />
                          {card.holderName || '名義未登録'}
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleCardReveal(card.id)}
                          className="flex items-center gap-1 text-[11px] font-medium text-indigo-400 hover:text-indigo-300"
                        >
                          {revealedCards.has(card.id) ? (
                            <>
                              <EyeOff className="w-3.5 h-3.5" /> 隠す
                            </>
                          ) : (
                            <>
                              <Eye className="w-3.5 h-3.5" /> 詳細を表示
                            </>
                          )}
                        </button>
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-500 block mb-0.5">カード番号</span>
                        <span className="font-mono text-sm text-slate-200 tracking-wider">
                          {revealedCards.has(card.id) ? formatCardNumber(card.number) : maskCardNumber(card.number, card.last4)}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <span className="text-[10px] text-slate-500 block mb-0.5">有効期限</span>
                          <span className="font-mono text-sm text-slate-200">
                            {revealedCards.has(card.id) ? (card.expiry || '未登録') : '••/••'}
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 block mb-0.5">セキュリティコード</span>
                          <span className="font-mono text-sm text-slate-200">
                            {revealedCards.has(card.id) ? (card.cvv || '未登録') : '•••'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* 詳細設定情報 */}
                    <div className="grid grid-cols-3 gap-2 bg-slate-900/50 p-3 rounded-xl text-xs border border-slate-700/40">
                      <div>
                        <span className="text-slate-400 block">利用限度額</span>
                        <span className="font-semibold text-slate-200">
                          {card.limit ? `¥${card.limit.toLocaleString()}` : '未設定'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">締め日</span>
                        <span className="font-semibold text-slate-200">{card.billingDay}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">支払日</span>
                        <span className="font-semibold text-slate-200">毎月{card.paymentDay}日</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </main>

      {/* 4. モーダル: 利用明細の記録 */}
      {isAddTransactionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-md w-full p-6 shadow-2xl relative space-y-4 max-h-[88vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-slate-700">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                利用明細の登録
              </h3>
              <button
                onClick={() => setIsAddTransactionOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddTransaction} className="space-y-4">
              {/* 利用金額 */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">利用金額 (円)</label>
                <input
                  type="number"
                  required
                  placeholder="例: 3500"
                  value={newTx.amount}
                  onChange={(e) => setNewTx({ ...newTx, amount: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-white font-bold text-lg focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* クレジットカード選択 */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">利用したカード</label>
                <select
                  value={newTx.cardId}
                  onChange={(e) => setNewTx({ ...newTx, cardId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                >
                  {cards.map((c) => (
                    <option key={c.id} value={c.id}>{c.name} ({c.brand})</option>
                  ))}
                </select>
              </div>

              {/* 利用日 & カテゴリ */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">利用日</label>
                  <input
                    type="date"
                    required
                    value={newTx.date}
                    onChange={(e) => setNewTx({ ...newTx, date: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">カテゴリ</label>
                  <select
                    value={newTx.category}
                    onChange={(e) => setNewTx({ ...newTx, category: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* メモ */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">メモ / 店舗名</label>
                <input
                  type="text"
                  placeholder="例: セブンイレブン、Amazonなど"
                  value={newTx.memo}
                  onChange={(e) => setNewTx({ ...newTx, memo: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddTransactionOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-medium text-sm hover:bg-slate-700/50"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow-lg shadow-indigo-600/30"
                >
                  保存する
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. モーダル: 新規カードの登録 */}
      {isAddCardOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-md w-full p-6 shadow-2xl relative space-y-4 max-h-[88vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-slate-700">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-indigo-400" />
                新しいカードを追加
              </h3>
              <button
                onClick={() => setIsAddCardOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCard} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">カード名</label>
                <input
                  type="text"
                  required
                  placeholder="例: 三井住友カード, 楽天ゴールドカード"
                  value={newCard.name}
                  onChange={(e) => setNewCard({ ...newCard, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">国際ブランド</label>
                <select
                  value={newCard.brand}
                  onChange={(e) => setNewCard({ ...newCard, brand: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                >
                  <option value="VISA">VISA</option>
                  <option value="Mastercard">Mastercard</option>
                  <option value="JCB">JCB</option>
                  <option value="Amex">American Express</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">カード番号</label>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={19}
                  placeholder="1234 5678 9012 3456"
                  value={newCard.number}
                  onChange={(e) => setNewCard({ ...newCard, number: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm font-mono tracking-wider focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">名義人</label>
                <input
                  type="text"
                  placeholder="例: TARO YAMADA"
                  value={newCard.holderName}
                  onChange={(e) => setNewCard({ ...newCard, holderName: e.target.value.toUpperCase() })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">有効期限</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={5}
                    placeholder="MM/YY"
                    value={newCard.expiry}
                    onChange={(e) => setNewCard({ ...newCard, expiry: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">セキュリティコード</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={4}
                    placeholder="123"
                    value={newCard.cvv}
                    onChange={(e) => setNewCard({ ...newCard, cvv: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* カードテーマ色設定 */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">カードデザインカラー</label>
                <div className="grid grid-cols-5 gap-2">
                  {Object.keys(CARD_THEMES).map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setNewCard({ ...newCard, theme: key })}
                      className={`h-10 rounded-xl ${CARD_THEMES[key].bg} border-2 transition-all ${
                        newCard.theme === key ? 'border-white scale-105' : 'border-transparent opacity-60'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* 利用限度額 */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">月間利用限度額 (円)</label>
                <input
                  type="number"
                  placeholder="300000"
                  value={newCard.limit}
                  onChange={(e) => setNewCard({ ...newCard, limit: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">締め日</label>
                  <input
                    type="text"
                    placeholder="例: 末日, 15日"
                    value={newCard.billingDay}
                    onChange={(e) => setNewCard({ ...newCard, billingDay: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">引き落とし日</label>
                  <input
                    type="text"
                    placeholder="例: 27日, 10日"
                    value={newCard.paymentDay}
                    onChange={(e) => setNewCard({ ...newCard, paymentDay: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddCardOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-medium text-sm hover:bg-slate-700/50"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow-lg shadow-indigo-600/30"
                >
                  登録する
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. 画像読み取り中のローディング */}
      {ocrLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl px-8 py-7 shadow-2xl flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-slate-200 font-medium">画像を読み取っています…</p>
            <p className="text-xs text-slate-500">初回は読み取りエンジンのダウンロードのため少し時間がかかります</p>
          </div>
        </div>
      )}

      {/* 7. モーダル: 自動検出できなかった時に、読み取れた生テキストを見せる */}
      {ocrRawText && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative space-y-4 max-h-[88vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-slate-700">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                明細を自動検出できませんでした
              </h3>
              <button
                onClick={() => setOcrRawText(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-400">
              画像からは以下のテキストが読み取れましたが、日付・金額の組み合わせを自動判定できませんでした。
              このままJSONファイルの読み込みをご利用いただくか、下の内容を開発者へ共有してください。
            </p>
            <pre className="whitespace-pre-wrap break-words bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-slate-300 max-h-64 overflow-y-auto">
{ocrRawText}
            </pre>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setOcrRawText(null)}
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow-lg shadow-indigo-600/30"
              >
                閉じる
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. モーダル: 画像読み取り結果の確認 */}
      {ocrReview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative space-y-4 max-h-[88vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-slate-700">
              <h3 className="font-bold text-lg text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                読み取り結果を確認
              </h3>
              <button
                onClick={() => setOcrReview(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-amber-200 bg-amber-500/10 border border-amber-500/20 rounded-xl px-3 py-2">
              画像から自動で読み取った内容です。日付・金額が正しいか確認してから追加してください。
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">追加先のカード</label>
              <select
                value={ocrReview.cardId}
                onChange={(e) => setOcrReview({ ...ocrReview, cardId: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
              >
                {cards.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            {ocrReview.candidates.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-6">すべての候補を削除しました。</p>
            ) : (
              <div className="space-y-3">
                {ocrReview.candidates.map((c, idx) => (
                  <div key={c.id} className="bg-slate-900/60 border border-slate-700/50 rounded-xl p-3 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="date"
                        value={c.date}
                        onChange={(e) => updateOcrCandidate(idx, { date: e.target.value })}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                      />
                      <input
                        type="number"
                        value={c.amount}
                        onChange={(e) => updateOcrCandidate(idx, { amount: e.target.value })}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-slate-200 text-xs font-mono focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={c.memo}
                        onChange={(e) => updateOcrCandidate(idx, { memo: e.target.value })}
                        placeholder="メモ"
                        className="flex-1 min-w-0 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="button"
                        onClick={() => removeOcrCandidate(idx)}
                        className="flex-none p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-lg"
                        title="この候補を削除"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <select
                      value={c.category}
                      onChange={(e) => updateOcrCandidate(idx, { category: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                    >
                      {CATEGORIES.map((cat) => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-2 flex gap-3">
              <button
                type="button"
                onClick={() => setOcrReview(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-medium text-sm hover:bg-slate-700/50"
              >
                キャンセル
              </button>
              <button
                type="button"
                onClick={handleConfirmOcrImport}
                disabled={ocrReview.candidates.length === 0}
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow-lg shadow-indigo-600/30 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {ocrReview.candidates.length}件を追加する
              </button>
            </div>
          </div>
        </div>
      )}

      <p className="text-center text-[11px] text-slate-600 py-6 px-4">
        データはこの端末のブラウザ内（localStorage）にのみ保存されます。
      </p>

    </div>
  );
}
